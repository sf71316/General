﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using General.Service.PrincipalManagement;

namespace General.Service
{
    public interface IPrincipalManagement
    {
        Device ReadDeviceByGuid(Guid deviceID);
        GroupMembership[] GetGroupMemberships(PrincipalIdentifier principalId);
        DeviceValue[] ReadAllDeviceValues(string deviceExternalID);
    }
}
