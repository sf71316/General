﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using General.Service.PrincipalManagement;
using System.Xml.Serialization;

namespace General.Service
{
    public interface IMSTVSubscribe
    {
        /// <summary>
        /// 回傳account下的明細資料
        /// </summary>
        /// <param name="acc"></param>
        /// <returns></returns>
        string AccountDetails(string acc);
        /// <summary>
        /// 增加1~n個用戶組(套餐) 
        /// </summary>
        /// <param name="pkgName"></param>
        /// <returns></returns>
        string AddPackage(string pkgName);
        /// <summary>
        /// BossGateway入口 
        /// </summary>
        /// <param name="cmd"></param>
        /// <returns></returns>
        string BossGateway(string cmd);
        /// <summary>
        /// 建新帳號 
        /// </summary>
        /// <param name="account"></param>
        string CreateAccount(string acc);
        /// <summary>
        /// 從設備讀取用戶帳號 
        /// </summary>
        /// <param name="dev"></param>
        /// <returns></returns>
        string GetAccountbyDeviceExternalId(string dev);
        /// <summary>
        /// 查詢SG by Account 
        /// </summary>
        /// <param name="accPlusSG"></param>
        /// <returns></returns>
        string GetDupSG(string accPlusSG);
        /// <summary>
        /// 取得SSL基本頻道 
        /// </summary>
        /// <returns></returns>
        string GetSSLBasicPackage();
        /// <summary>
        /// 區分全區or屯區 
        /// </summary>
        /// <param name="acc"></param>
        /// <returns></returns>
        string QuanTuen(string acc);
        /// <summary>
        /// 讀取用戶組(套餐) 
        /// </summary>
        /// <param name="acc"></param>
        /// <returns></returns>
        string[] ReadAccountSubscriberGroups(string acc);
        /// <summary>
        /// 移除1~n個用戶組(套餐) 
        /// </summary>
        /// <param name="pkgName"></param>
        /// <returns></returns>
        string RemovePackage(string pkgName);
        /// <summary>
        /// xmlMapping_sg2coss 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        string XMLsgMapping2coss(string id);
        /// <summary>
        /// devCluster入口 SG_DEVIC08開頭SG
        /// </summary>
        /// <param name="cm"></param>
        /// <returns></returns>
        string devCluster(string cm);
        /// <summary>
        /// 取得coss排程table序號
        /// </summary>
        /// <returns></returns>
        string getMSWDSeq();
        /// <summary>
        /// 讀取設備下SG
        /// </summary>
        /// <param name="dev"></param>
        /// <returns></returns>
        string log_GetDeviceSG(string dev);
        /// <summary>
        /// 讀取User_AccountExternalId_ExternalID 
        /// </summary>
        /// <param name="acc"></param>
        void log_GetUser(string acc);
        /// <summary>
        /// 取得帳號的明細 
        /// </summary>
        /// <param name="acc"></param>
        void log_getAccDetails(string acc);
        /// <summary>
        /// removeUser 
        /// </summary>
        /// <param name="acc"></param>
        /// <returns></returns>
        string removeUser(string acc);
        /// <summary>
        /// setMaster:成功6/失敗0/異常10 
        /// </summary>
        /// <param name="acc"></param>
        /// <returns></returns>
        string setMaster(string acc);
        /// <summary>
        /// setUser 
        /// </summary>
        /// <param name="acc"></param>
        /// <returns></returns>
        string setUser(string acc);
        /// <summary>
        /// xml入口 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        string sgMapping(string id);
        /// <summary>
        /// sg-->device 
        /// </summary>
        /// <param name="pkgName"></param>
        /// <returns></returns>
        string sgToDevice(string pkgName);
        /// <summary>
        /// 由stb呼叫購買 
        /// </summary>
        /// <param name="accREC"></param>
        /// <returns></returns>
        string stbToPurchase(string accREC);
        /// <summary>
        /// 回傳account下是否還有設備
        /// </summary>
        /// <param name="rc"></param>
        /// <returns></returns>
        string ynDev(string rc);
    }
}
